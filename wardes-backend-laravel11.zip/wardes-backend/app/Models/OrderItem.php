<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    public $timestamps = false;
    protected $fillable = ['order_id','product_id','quantity','price_at_purchase'];
    protected function casts(): array { return ['quantity'=>'integer','price_at_purchase'=>'decimal:2']; }
    public function order() { return $this->belongsTo(Order::class); }
    public function product() { return $this->belongsTo(Product::class); }
}
